# 🥊 GUIA OFICIAL & TUTORIAL DO JOGO: FIGHTER CAREER SIMULATOR

Bem-vindo ao **Fighter Career Simulator** (Iron Will: Combat Legacy)! Este é um simulador de carreira e combate ultra-detalhado, onde você guia a trajetória de um atleta desde a juventude até a consagração como Campeão Mundial e Medalhista de Ouro Olímpico.

---

## 📑 ÍNDICE
1. [Criação do Lutador & DNA das Lendas](#1-criação-do-lutador--dna-das-lendas)
2. [O Ciclo do Calendário: Camps de 4 Meses](#2-o-ciclo-do-calendário-camps-de-4-meses)
3. [Como Funciona o Combate (No Ringue / Octógono)](#3-como-funciona-o-combate-no-ringue--octógono)
   - [As 4 Barras de Vida e Condição](#as-4-barras-de-vida-e-condição)
   - [Como Nocautear na Perna (TKO de Chutes Baixos)](#como-nocautear-na-perna-tko-de-chutes-baixos)
   - [Como Nocautear no Corpo (Golpes no Fígado)](#como-nocautear-no-corpo-golpes-no-fígado)
   - [Como Nocautear na Cabeça (Queixo)](#como-nocautear-na-cabeça-queixo)
   - [Finalizações e Luta de Solo](#finalizações-e-luta-de-solo)
   - [Esquivas e Skill Checks (Reflexos)](#esquivas-e-skill-checks-reflexos)
4. [Evolução do Lutador: XP e Pontos de Habilidade (PH)](#4-evolução-do-lutador-xp-e-pontos-de-habilidade-ph)
5. [Loja de Golpes & Especialização Técnica](#5-loja-de-golpes--especialização-técnica)
6. [Gestão de Vida, Academias & Finanças](#6-gestão-de-vida-academias--finanças)
7. [Campeonatos e o Sonho Olímpico](#7-campeonatos-e-o-sonho-olímpico)

---

## 1. CRIAÇÃO DO LUTADOR & DNA DAS LENDAS

Ao iniciar uma nova carreira, você passará pelo **Assistente de Criação**:
- **Passo 1: Identidade & Cidade Natal**
  - Defina Nome, Apelido, Gênero, Base de Luta (Destro, Canhoto ou Switch) e sua Cidade/Estado natal.
- **Passo 2: Modalidade & Categoria de Peso**
  - Escolha entre **Boxe**, **Jiu-Jitsu (BJJ)**, **MMA**, **Muay Thai**, **Kickboxing**, **Judô** ou **Wrestling**.
  - A modalidade define seus golpes iniciais e o circuito onde você competirá.
- **Passo 3: DNA das Lendas (Teto Genético)**
  - O teto dos seus atributos é definido pelas habilidades que você herda de lendas do esporte (Mike Tyson, Anderson Silva, Khabib, Royce Gracie, Buakaw, etc.).
  - Esse teto é o valor máximo que você poderá alcançar em cada atributo ao longo de toda a sua vida esportiva. Use o botão `⚡ Sortear Restantes` para preencher rapidamente se desejar.
- **Passo 4: Distribuição Inicial de Atributos**
  - Ajuste os atributos iniciais da sua modalidade (Força, Queixo, Gás, Mãos, etc.).
- **Passo 5: Personalidade & Estilo**
  - Escolha entre estilos como *Agressivo*, *Contragolpeador*, *Estrategista*, etc.
- **Passo 6: Lançar Carreira!**

---

## 2. O CICLO DO CALENDÁRIO: CAMPS DE 4 MESES

O tempo do jogo não corre por dia a dia avulso: ele avança por **Camps (Quadrimestres de 4 Meses)**:
- **Camp 1**: Janeiro a Abril
- **Camp 2**: Maio a Agosto
- **Camp 3**: Setembro a Dezembro (ao final deste, seu lutador completa aniversário).

### ⚠️ Regra Fundamental: Limite de 6 Lutas por Camp
- Cada Camp possui uma programação de **até 6 combates oficiais**.
- **Os meses do calendário NÃO avançam se você não completar as 6 lutas programadas deste Camp!**
- Ao disputar as 6 lutas (`6/6`), a aba de Lutas e o Painel de Carreira liberam o botão:
  `⏩ Concluir Camp & Avançar 4 Meses`.
- Ao clicar em avançar:
  - O calendário soma **+4 meses**.
  - Sua energia se recupera e a fadiga diminui.
  - O contador de lutas é zerado (`0/6`) para o novo ciclo.

---

## 3. COMO FUNCIONA O COMBATE (NO RINGUE / OCTÓGONO)

### As 4 Barras de Vida e Condição
Tanto você quanto seu adversário possuem 4 barras fundamentais durante a luta:
1. **Cabeça / Queixo (Chin & Head HP)**: Se esgotar, o lutador sofre **KO tradicional na cabeça**.
2. **Corpo / Fígado (Body HP)**: Mede a resistência a ganchos no fígado, chutes na costela e joelhadas.
3. **Pernas (Legs HP)**: Mede a integridade muscular e articular das pernas contra chutes baixos (Low Kicks / Calf Kicks).
4. **Estamina / Gás (Stamina)**: Oxigênio disponível. Golpear gasta estamina; se esgotar, o lutador fica exausto e sofre mais dano.

---

### 🦵 Como Nocautear Batendo Só na Perna (TKO de Chutes Baixos)
- **Estratégia**: Use ataques baixos repetidamente (`Chute Baixo / Low Kick`, `Calf Kick na Panturrilha`, `Canelada Baixa`).
- **Knockdown de Perna**: Quando a barra de Pernas do rival cai abaixo de 35%, ele falseia o apoio e sofre knockdown!
- **Encerramento por TKO**: Se a barra de pernas do adversário chegar a **0**, a luta é interrompida imediatamente com **Vitória por Nocaute Técnico (TKO de Perna)**!
- *Atenção:* O adversário também pode nocautear você na perna se você não bloquear ou esquivar dos chutes dele!

---

### 🥊 Como Nocautear Batendo Só no Corpo (Golpe no Fígado / Costelas)
- **Estratégia**: Mire na linha de cintura (`Gancho no Fígado`, `Chute Médio nas Costelas`, `Joelhadas no Clinch`).
- **Efeito no Gás**: Cada golpe certeiro no corpo drena também a estamina do adversário.
- **Knockdown de Tronco**: Ao reduzir a vida de corpo a menos de 35%, o oponente dobra de joelhos sem ar.
- **Encerramento por KO de Corpo**: Se a barra de corpo chegar a **0**, a luta acaba na hora por **Nocaute com Golpe no Fígado/Corpo (KO)**!

---

### 💥 Como Nocautear na Cabeça (Queixo)
- Golpes clássicos de nocaute (`Direto`, `Cruzado`, `Uppercut`, `Overhand`, `Chute Alto`).
- Ao zerar a vida de cabeça/queixo, ocorre o **Nocaute Limpo (KO)**.

---

### 🥋 Finalizações e Luta de Solo
- Se sua modalidade permitir chão (BJJ, MMA, Judô, Wrestling), use ações de queda (`Double Leg`, `Queda de Judô`, `Mergulho`) para levar o adversário ao solo.
- No tatame, avance posições (Guarda -> Meia-Guarda -> Montada -> Pegada de Costas).
- Aplique finalizações como **Mata-Leão**, **Armlock**, **Guilhotina**, **Triângulo** ou **Chave de Calcanhar** para vencer por Finalização (SUB).

---

### ⚡ Esquivas e Skill Checks (Reflexos)
- Quando o adversário dispara golpes perigosos, pode surgir na tela um **Skill Check de Reflexo** (estilo Dead by Daylight):
  - **Zona Perfeita (GREAT)**: Você faz o pêndulo, desvia 100% do dano e acerta um **Contragolpe Crítico** devastador de encontro!
  - **Zona Boa (SUCCESS)**: Você esquiva com classe e o golpe do rival corta apenas o ar.
  - **Falha**: O ataque conecta em cheio.

---

## 4. EVOLUÇÃO DO LUTADOR: XP E PONTOS DE HABILIDADE (PH)

A cada vitória nos combates, você recebe duas recompensas cruciais:
1. **XP (Experiência)**:
   - Utilizado na aba **Atributos** para aumentar suas notas de Força, Queixo, Gás, Velocidade, Boxe, BJJ, etc.
   - Cada atributo pode evoluir até o limite estipulado pelo seu **DNA das Lendas**.
2. **PH (Pontos de Habilidade)**:
   - Você ganha de 1 a 5 PH por vitória (com bônus por nocautes e finalizações plásticas).
   - Utilizados na **Loja de Golpes** para comprar golpes e técnicas especiais.

---

## 5. LOJA DE GOLPES & ESPECIALIZAÇÃO TÉCNICA

Na aba **Golpes**:
- Você encontra golpes especiais exclusivos da sua arte marcial.
- Cada golpe possui um custo em PH, valor de dano, custo de estamina e chance de nocaute.
- Ao comprar um golpe, ele passa a aparecer como botão selecionável durante as rodadas de combate!

---

## 6. GESTÃO DE VIDA, ACADEMIAS & FINANÇAS

Na aba **Vida** e **Academia**:
- **Trabalhos**: No início da carreira, arrume um emprego (segurança, garçom, instrutor) para pagar contas e suplementos. Conforme sua fama cresce, bolsas de luta e patrocínios sustentam você.
- **Moradia**: Melhore de casa para acelerar sua recuperação de energia e reduzir o estresse.
- **Academias & Treinadores**: Troque para centros de treinamento de ponta para ganhar multiplicadores nos treinos de cada camp.

---

## 7. CAMPEONATOS E O SONHO OLÍMPICO

- **Idade 15 Anos**: Desbloqueia o **Campeonato Estadual oficial**.
- **Idade 16 Anos**: Desbloqueia a **Taça Nacional** e os índices classificatórios internacionais.
- **Idade 17 Anos**: Desbloqueia o circuito **Continental & Sul-Americano**.
- **Idade 18 Anos (Maioridade)**: Desbloqueia contratos mundiais e o circuito do **UFC**.
- **🥇 JOGOS OLÍMPICOS (A Cada 4 Anos)**:
  - O torneio olímpico acontece rigorosamente a cada 4 anos da carreira (Ano 1, Ano 5, Ano 9...).
  - Conquistar a Medalha de Ouro consagra seu nome na história do país e concede bônus permanentes de fama e prestígio!

---

### 🕹️ Dica de Ouro para Iniciantes:
> *No primeiro camp, dispute suas 6 lutas no circuito amador ou municipal para acumular XP e PH. Compre o primeiro golpe especial e melhore seu condicionamento físico antes de avançar para os desafios de maior prestígio!*
